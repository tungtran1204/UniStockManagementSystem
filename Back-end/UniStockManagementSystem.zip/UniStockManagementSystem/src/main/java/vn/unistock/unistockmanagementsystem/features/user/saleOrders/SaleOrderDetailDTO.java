package vn.unistock.unistockmanagementsystem.features.user.saleOrders;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SaleOrderDetailDTO {
    private Long orderDetailId;
    private Long orderId;
    private Long productId;
    private Double quantity;
    private Double unitPrice;
    private Double discount;
    private LocalDateTime createdAt;
    private Long createdBy;
    private LocalDateTime updatedAt;
    private Long updatedBy;
}
