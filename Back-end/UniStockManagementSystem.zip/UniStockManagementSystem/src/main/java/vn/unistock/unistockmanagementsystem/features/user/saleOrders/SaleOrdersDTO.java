package vn.unistock.unistockmanagementsystem.features.user.saleOrders;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SaleOrdersDTO {
    private Long id;
    private String customerName;
    private Double price;
    private String status;
    private LocalDateTime orderDate;


    //private Date createdAt;
    //private Date updatedAt;

    //private Long createdBy;
    //private Long updatedBy;
}