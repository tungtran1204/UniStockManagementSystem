package vn.unistock.unistockmanagementsystem.features.user.saleOrders;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/unistock/user/saleorders")
public class SaleOrdersController {
    private final SaleOrdersService saleOrdersService;

    public SaleOrdersController(SaleOrdersService saleOrdersService) {
        this.saleOrdersService = saleOrdersService;
    }

    @GetMapping
    public ResponseEntity<List<SaleOrdersDTO>> getAllOrders() {
        return ResponseEntity.ok(saleOrdersService.getAllOrders());
    }
}
