package vn.unistock.unistockmanagementsystem.features.user.saleOrders;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SaleOrdersService {
    private final SaleOrdersRepository saleOrdersRepository;

    public SaleOrdersService(SaleOrdersRepository saleOrdersRepository) {
        this.saleOrdersRepository = saleOrdersRepository;
    }

    public List<SaleOrdersDTO> getAllOrders() {
        return saleOrdersRepository.findAllOrdersWithDetails();
    }
}
