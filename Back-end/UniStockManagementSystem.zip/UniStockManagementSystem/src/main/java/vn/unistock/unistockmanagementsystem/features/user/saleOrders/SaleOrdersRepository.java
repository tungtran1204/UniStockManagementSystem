package vn.unistock.unistockmanagementsystem.features.user.saleOrders;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import vn.unistock.unistockmanagementsystem.entities.SalesOrder;

import java.util.List;

public interface SaleOrdersRepository extends JpaRepository<SalesOrder, Long> {

    @Query("""
    SELECT new vn.unistock.unistockmanagementsystem.features.user.saleOrders.SaleOrdersDTO(
        o.orderId, 
        c.custName, 
        o.price, 
        o.status, 
        o.orderDate)
    FROM SalesOrder o
    LEFT JOIN Customer c ON o.customer.id = c.id
    LEFT JOIN SalesOrderDetail d ON d.salesOrder.orderId = o.orderId
    GROUP BY o.orderId, c.custName, o.status, o.orderDate
""")
    List<SaleOrdersDTO> findAllOrdersWithDetails();
}
