package vn.unistock.unistockmanagementsystem.entities;

public class Stock {
}
